<?php

namespace App\Controller;

use App\Entity\Auteur;
use App\Form\AuteurFormType;
use App\Repository\AuteurRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class AuteurController extends AbstractController
{
    /**
     * Pour ajouter une route dans un projet Symfony, on utilise les attributs PHP 8
     * (ou les annotations si on utilise PHP 7).
     * Le constructeur de la classe Route a un argument obligatoire, le chemin relatif,
     * c'est-à-dire l'URL pour lequel cette méthode sera exécutée.
     * ⚠ le chemin doit toujours commencer par "/"
     * Dans Symfony, toutes les méthodes du contrôleur (liées à une route)  
     * doivent retourner un objet de la classe RESPONSE
     */
    #[Route('/auteurs', name: 'app_auteur')]
    public function index(AuteurRepository $auteurRepository): Response
    {
        /**
         * La méthode 'render' va générer l'affichage :
         * 1er argument : le fichier qui va être utilisé pour l'affichage
         * 2ème argument (optionel) : il doit être de type array. Il contient
         *          les variables qui seront utilisés dans le fichier utilisé pour 
         *          l'affichage. C'est une array ASSOCIATIF
         * 
         * NB : le nom du fichier est donné à partir du dossier "templates"
        */
        $listeAuteurs = $auteurRepository->findAll();
        // foreach($listeAuteurs as $auteur) {
        //     echo $auteur->getNom();
        // }


        // dd($listeAuteurs);  // dd : Dump and Die : affiche le var_dump et arrête l'exécution du code
        return $this->render('auteur/index.html.twig', [
            "auteurs" => $listeAuteurs
        ]);
    }

    /**
     * Dans le chemin d'une route, la partie entre {} est un paramètre de la route.
     * Cette partie est dynamique, c'es-à-dire qu'elle peut ^tre rempladcée par n'importe
     * quelle chaîne de caractères.
     * Pour récupérer cette valeur, il faut déclarer un argument dans la méthode qui aura
     * exactement le même nom que le paramètre de la route.
     */
    #[Route('/auteur/{id}', name: 'app_auteur_fiche', requirements: ["id" => "\d+"])]
    public function fiche($id, AuteurRepository $ar)
    {
        $auteur = $ar->find($id);
        return $this->render("auteur/fiche.html.twig", [
            "auteur" => $auteur
        ]);
    }


    #[Route('/auteur/ajouter', name: 'app_auteur_ajouter')]
    public function ajouter(Request $rq, AuteurRepository $ar){
        $auteur = new Auteur;
        $form = $this->createForm(AuteurFormType::class, $auteur);
        $form->handleRequest($rq);
        if( $form->isSubmitted() && $form->isValid() ) {
            $ar->save($auteur, true);
            return $this->redirectToRoute("app_auteur");
        }
        return $this->render("auteur/formulaire.html.twig", [
            "formAuteur" => $form->createView()
        ]);
    }







    #[Route('/auteur/test', name: 'app_auteur_test')]
    public function test()
    {
        $variable = 75;
        echo $variable;
        return $this->render("base.html.twig", [ 
            "variable" => 75, 
            "nombre" => 2,
            "prenom" => "François" 
        ]);

        // EXERCICE : comment supprimer le message d'erreur
        // et afficher le prénom "François"
    }

    /* EXERCICE 2 : ajouter une nouvelle route pour le 
            chemin "/auteur/salut" qui affiche
            "Salut " suivi de votre prénom qui doit être 
            passé en comme variable à la vue.
            Il faut ajouter une vue (fichier twig) dans
            le dossier "templates/auteur" qui s'appelera
            "salut.html.twig"
    */
    #[Route('/auteur/salut', name: 'app_auteur_salut')]
    public function salut()
    {
        $prenom = "Didier";
        return $this->render("auteur/salut.html.twig", [
            "prenom" => $prenom
        ]);

    }

    #[Route('/auteur/salut/test', name: 'app_auteur_salut_test')]
    public function salutTest()
    {
        return $this->render("auteur/test.html.twig", [
            "prenom" => "gertrude"
        ]);
    }


}

<?php

namespace App\Controller;

use App\Entity\Livre;
use App\Repository\AuteurRepository;
use App\Repository\LivreRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class LivreController extends AbstractController
{
    #[Route('/livres', name: 'app_livre')]
    public function index(LivreRepository $lr): Response
    {
        return $this->render('livre/index.html.twig', [
            "livres" => $lr->findAll()  // findAll retourne un tableau d'objets de la classe Livre
        ]);
    }

    /**
     * l'argument 'requirements' permet de mettre une contrainte sur les paramètres d'une route.
     * On utilise une expression régulière (ou REGEX) pour choisir le schéma que doit respecter
     * la chaîne de caractères. Par exemple :
     *      [0-9]+       signifie        n'importe quel chiffre peut être présént 1 ou plusieurs fois
     *      \d+                          \d = digit (chiffre)
     */
    #[Route("/livre/{id}", name: 'app_livre_fiche', requirements: ['id' => '[0-9]+' ])]
    public function fiche($id, LivreRepository $lr)
    {
        return $this->render('livre/fiche.html.twig', [
            "livre" => $lr->find($id)  // find retourne un objet de la classe Livre
        ]);
    }

    /**
     * L'objet de la classe Request contient toutes les valeurs de toutes les variables superglobales de PHP. Pour
     * chacune des superglobales, il y a une propriété publique qui correspond.
     *      $_GET       correspond à        $request->query
     *      $_POST                          $request->request
     * 
     * Ces propriétés sont des objets qui ont des méthodes communes : get, has, ...
     * 𝒆̲̅𝒙̲̅ : $_POST["titre"]    avec $request    $request->request->get("titre")
     *      $_GET["titre"]                      $request->query->get("titre")
     * 
     * ⚠ cet objet doit être utilisé en déclarant un argument d'une méthode d'un contrôleur (=injection de dépendance)
     */
    #[Route("/livre/ajouter", name: 'app_livre_ajouter')]
    public function ajouter(Request $request, LivreRepository $livreRepository, AuteurRepository $auteurRepository)
    {
        if( $request->isMethod("POST") ) {
            $titre = $request->request->get("titre");  // récupère les données du formulaire dans des variables
            $resume = $request->request->get("resume");
            $auteur_id = $request->request->get("auteur_id");
            $auteur = $auteurRepository->find($auteur_id);

            $livre = new Livre;
            $livre->setTitre($titre);
            $livre->setResume($resume);
            $livre->setAuteur($auteur);

            $livreRepository->save($livre, true);  // insère les données dans la table Livre
            return $this->redirectToRoute("app_livre");
        }
        return $this->render("livre/formulaire.html.twig", [
            "auteurs" => $auteurRepository->findAll()
        ]);
    }

    #[Route("/livre/{id}/modifier", name: "app_livre_modifier", requirements:["id" => "\d+"])]
    public function modifier(Request $request, LivreRepository $livreRepository, int $id, AuteurRepository $auteurRepository)
    {
        $livre = $livreRepository->find($id);
        if( $request->isMethod("POST") ) {
            $titre = $request->request->get("titre");  // récupère les données du formulaire dans des variables
            $resume = $request->request->get("resume");

            $livre->setTitre($titre);
            $livre->setResume($resume);
            $livre->setAuteur($auteurRepository->find($request->request->get("auteur_id")));
            
            $livreRepository->save($livre, true);  // actualise les données dans la table Livre
            return $this->redirectToRoute("app_livre");
        }
        return $this->render("livre/formulaire.html.twig", [ 
            "livre" => $livre,
            "auteurs" => $auteurRepository->findAll()
         ]);
    }

    #[Route("/livre/{id}/supprimer", name: "app_livre_supprimer", requirements:["id" => "\d+"])]
    public function supprimer(Request $request, LivreRepository $livreRepository, int $id)
    {
        $livre = $livreRepository->find($id);
        if( $request->isMethod("POST") ) {
            $livreRepository->remove($livre, true);     // supprime l'enregistrement dans la table livre
            return $this->redirectToRoute("app_livre");
        }
        return $this->render("livre/suppression.html.twig", [ "livre" => $livre ]);
        
    }



}
